"""Compila os dois módulos MyBible sem substituir uma versão boa em caso de erro."""
from __future__ import annotations

from html import escape
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
import uuid
from typing import Any

from .arquivos import DadosInvalidos, ler_todos
from .catalogo import LIVROS, POR_NUMERO
from .fontes import ATRIBUICAO
from .trava import trava


class ErroCompilacao(RuntimeError):
    pass


def _temporario(pasta: Path, prefixo: str) -> Path:
    fd, caminho = tempfile.mkstemp(prefix=prefixo, suffix='.bee-tmp', dir=pasta)
    os.close(fd)
    return Path(caminho)


def _criar_biblia(caminho: Path, livros: dict[int, dict[str, Any]], build_id: str, completo: bool, lacunas_fonte: int) -> int:
    conexao = sqlite3.connect(caminho)
    try:
        with conexao:
            conexao.executescript('''
                CREATE TABLE info (name TEXT, value TEXT);
                CREATE UNIQUE INDEX info_index ON info (name);
                CREATE TABLE books (book_number INTEGER, book_color TEXT, short_name TEXT, long_name TEXT);
                CREATE UNIQUE INDEX books_index ON books (book_number);
                CREATE TABLE books_all (book_number INTEGER, book_color TEXT, short_name TEXT, long_name TEXT, is_present BOOLEAN);
                CREATE UNIQUE INDEX books_all_index ON books_all (book_number);
                CREATE TABLE introductions (book_number INTEGER, introduction TEXT);
                CREATE UNIQUE INDEX introductions_index ON introductions (book_number);
                CREATE TABLE verses (book_number INTEGER, chapter INTEGER, verse INTEGER, text TEXT);
                CREATE UNIQUE INDEX verses_index ON verses (book_number, chapter, verse);
            ''')
            info = {
                'description': 'Bíblia de Estudo Epignósis (BEE)',
                'detailed_info': 'Rascunho gerado por IA a partir de edições textuais, em estilo clássico modernizado; requer revisão humana.',
                'language': 'pt', 'russian_numbering': 'false', 'strong_numbers': 'false',
                'source': ATRIBUICAO,
                'bee_build_id': build_id,
                'bee_complete': str(completo).lower(),
                'bee_source_gaps': str(lacunas_fonte),
                'bee_review_status': 'Rascunho gerado por IA; revisão humana necessária.',
            }
            conexao.executemany('INSERT INTO info (name, value) VALUES (?, ?)', info.items())
            introducao = '<p><b>Fontes, licenças e revisão:</b> ' + escape(ATRIBUICAO) + '</p>'
            conexao.execute('INSERT INTO introductions (book_number, introduction) VALUES (0, ?)', (introducao,))
            for livro in LIVROS:
                presente = livro.numero in livros and bool(livros[livro.numero]['chapters'])
                registro = (livro.numero, livro.cor, livro.abreviatura, livro.nome)
                conexao.execute('INSERT INTO books_all VALUES (?, ?, ?, ?, ?)', (*registro, int(presente)))
                if presente:
                    conexao.execute('INSERT INTO books VALUES (?, ?, ?, ?)', registro)
            registros = (
                (numero, int(capitulo), versiculo['verse'], versiculo['text'])
                for numero, dados in sorted(livros.items())
                for capitulo, versiculos in sorted(dados['chapters'].items(), key=lambda item: int(item[0]))
                for versiculo in versiculos
            )
            conexao.executemany('INSERT INTO verses (book_number, chapter, verse, text) VALUES (?, ?, ?, ?)', registros)
        total = conexao.execute('SELECT COUNT(*) FROM verses').fetchone()[0]
        if conexao.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ErroCompilacao('Verificação de integridade da Bíblia falhou.')
        return total
    finally:
        conexao.close()


def _criar_comentarios(caminho: Path, livros: dict[int, dict[str, Any]], build_id: str, completo: bool, lacunas_fonte: int) -> int:
    conexao = sqlite3.connect(caminho)
    try:
        with conexao:
            # A ordem dos sete campos iniciais segue o formato MyBible publicado.
            # book_number_to é um campo adicional solicitado pelo projeto; como
            # cada comentário cobre um único versículo, é igual a book_number.
            conexao.executescript('''
                CREATE TABLE info (name TEXT, value TEXT);
                CREATE UNIQUE INDEX info_index ON info (name);
                CREATE TABLE commentaries (
                    book_number INTEGER, chapter_number_from INTEGER, verse_number_from INTEGER,
                    chapter_number_to INTEGER, verse_number_to INTEGER, marker TEXT, text TEXT,
                    book_number_to INTEGER
                );
                CREATE UNIQUE INDEX commentaries_index ON commentaries
                    (book_number, chapter_number_from, verse_number_from);
            ''')
            info = {
                'description': 'Comentários Exegéticos e Léxicos - BEE',
                'detailed_info': 'Fontes, licenças e revisão: ' + ATRIBUICAO,
                'language': 'pt', 'is_footnotes': 'false',
                'source': ATRIBUICAO,
                'bee_build_id': build_id,
                'bee_complete': str(completo).lower(),
                'bee_source_gaps': str(lacunas_fonte),
                'bee_review_status': 'Rascunho gerado por IA; revisão humana necessária.',
            }
            conexao.executemany('INSERT INTO info (name, value) VALUES (?, ?)', info.items())
            registros = (
                (numero, int(capitulo), versiculo['verse'], int(capitulo), versiculo['verse'],
                 '', versiculo['commentary'], numero)
                for numero, dados in sorted(livros.items())
                for capitulo, versiculos in sorted(dados['chapters'].items(), key=lambda item: int(item[0]))
                for versiculo in versiculos
            )
            conexao.executemany(
                'INSERT INTO commentaries (book_number, chapter_number_from, verse_number_from, '
                'chapter_number_to, verse_number_to, marker, text, book_number_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                registros,
            )
        total = conexao.execute('SELECT COUNT(*) FROM commentaries').fetchone()[0]
        if conexao.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ErroCompilacao('Verificação de integridade dos comentários falhou.')
        return total
    finally:
        conexao.close()


def _publicar(pares: list[tuple[Path, Path]], pasta: Path) -> None:
    backups: dict[Path, Path | None] = {}
    publicados: list[Path] = []
    preservar: set[Path] = set()
    try:
        # Prepare os dois backups ANTES de substituir qualquer módulo.
        for _, destino in pares:
            if destino.exists():
                backup = _temporario(pasta, '.backup-bee-')
                backups[destino] = backup
                shutil.copy2(destino, backup)
            else:
                backups[destino] = None
        for origem, destino in pares:
            os.replace(origem, destino)
            publicados.append(destino)
    except BaseException as original:
        erros: list[str] = []
        for destino in reversed(publicados):
            backup = backups[destino]
            try:
                if backup is None:
                    destino.unlink(missing_ok=True)
                else:
                    os.replace(backup, destino)
            except OSError as exc:
                if backup is not None:
                    preservar.add(backup)
                    erros.append(f'{destino}: restaure manualmente {backup} ({exc})')
                else:
                    erros.append(f'{destino}: não foi possível remover o novo ficheiro ({exc})')
        if erros:
            raise ErroCompilacao('Falhou a reversão dos módulos: ' + '; '.join(erros)) from original
        raise
    finally:
        for backup in backups.values():
            if backup is not None and backup not in preservar:
                backup.unlink(missing_ok=True)


def compilar(diretorio_json: Path, diretorio_saida: Path) -> dict[str, int | bool | str]:
    # Duas pastas de dados distintas também não devem publicar ao mesmo tempo
    # no mesmo diretório de saída. A trava separada funciona mesmo se os
    # diretórios de dados e de saída forem iguais.
    with trava(diretorio_saida, nome='.bee.compile.lock'):
        return _compilar_travado(diretorio_json, diretorio_saida)


def _compilar_travado(diretorio_json: Path, diretorio_saida: Path) -> dict[str, int | bool | str]:
    livros = ler_todos(diretorio_json)
    capitulos = sum(len(dados['chapters']) for dados in livros.values())
    parciais = sum(len(dados.get('in_progress', {})) for dados in livros.values())
    if capitulos == 0:
        raise ErroCompilacao('Não há capítulos completos para compilar. Gere pelo menos um primeiro.')
    for numero, dados in livros.items():
        disponiveis = sorted(int(chave) for chave in dados['chapters'])
        if disponiveis and disponiveis != list(range(1, disponiveis[-1] + 1)):
            raise DadosInvalidos(
                f'{POR_NUMERO[numero].nome}: capítulos têm lacunas; MyBible requer capítulos consecutivos a partir de 1.'
            )
    completo = capitulos == sum(l.capitulos for l in LIVROS)
    lacunas_fonte = sum(
        v['text'].startswith('[Versículo sem texto correspondente no WLC consultado.]')
        for dados in livros.values() for versiculos in dados['chapters'].values() for v in versiculos
    )
    diretorio_saida.mkdir(parents=True, exist_ok=True)
    id_compilacao = uuid.uuid4().hex
    bible_temp = _temporario(diretorio_saida, '.BEE-')
    comentarios_temp = _temporario(diretorio_saida, '.BEE-comentarios-')
    try:
        total_versos = _criar_biblia(bible_temp, livros, id_compilacao, completo, lacunas_fonte)
        total_comentarios = _criar_comentarios(comentarios_temp, livros, id_compilacao, completo, lacunas_fonte)
        if total_versos == 0 or total_versos != total_comentarios:
            raise ErroCompilacao('Inconsistência entre os módulos; os ficheiros anteriores foram preservados.')
        _publicar([
            (bible_temp, diretorio_saida / 'BEE.SQLite3'),
            (comentarios_temp, diretorio_saida / 'BEE.commentaries.SQLite3'),
        ], diretorio_saida)
    except (OSError, sqlite3.Error) as exc:
        raise ErroCompilacao(f'Não foi possível compilar/publicar os módulos: {exc}') from exc
    finally:
        bible_temp.unlink(missing_ok=True)
        comentarios_temp.unlink(missing_ok=True)
    return {
        'livros': sum(bool(v['chapters']) for v in livros.values()),
        'capitulos': capitulos, 'parciais': parciais, 'versiculos': total_versos,
        'lacunas_fonte': lacunas_fonte, 'completo': completo, 'build_id': id_compilacao,
    }
